//
//  main.m
//  PhantomPlatform
//
//  Created by cosmic-life on 14-1-18.
//  Copyright (c) 2014年 Phantom Game Studios. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
